# Sentiment Analysis Project — how to run

## Files
| File | What it is |
|---|---|
| `Sentiment_Analysis_Project.ipynb` | Main deliverable: full notebook with code, comments, outputs and charts |
| `Sentiment_Analysis_Project.html` | The same notebook as a single web page (open in any browser, no Python needed) |
| `sentiment_analysis.py` | Same code as a plain script |
| `Insights_Report.md` | Written findings and limitations |
| `processed_social_media_reviews.csv` | **Processed dataset** (Instagram + Twitter combined, with sentiment scores and labels) |
| `processed_instagram_reviews.csv`, `processed_twitter_tweets.csv` | Same data split by platform |
| `charts/` | 12 PNG charts |

## Run it yourself
```
pip install -r requirements.txt
# put the two CSV files in the same folder, then either:
jupyter notebook Sentiment_Analysis_Project.ipynb
# or
python sentiment_analysis.py
```
NLTK downloads the VADER lexicon and stopwords automatically on first run.

## Processed dataset columns
`review_id, user_id, username, platform, age_group, location, date, review_text, cleaned_review, hashtags, topic, likes, retweets, replies, sentiment_score, sentiment, sentiment_score_raw, sentiment_raw`

- `sentiment_score` / `sentiment` = VADER compound score and label on the **cleaned** text (the main result).
- `sentiment_score_raw` / `sentiment_raw` = same, on the original text (robustness check only).
- `date` and `retweets` exist only for Twitter; `username` only for Twitter.
